package academy.digitallab.store.servicecustomer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceCustomerApplicationTests {

	@Test
	void contextLoads() {
	}

}
